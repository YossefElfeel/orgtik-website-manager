Orgtik icon set v2
24 x 24 grid, 2 px stroke, round caps.
Colour: #8135CD (use currentColor in code).
Designer: Laila Mostafa
